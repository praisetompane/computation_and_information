﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Files.and.Streams
{
    class Employee
    {
        public string mID;
        public string mName;
        public double mSalary;
    }
}
