﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Structs
{
    struct Person
    {
        string ID;

    }
    class Program
    {
        static void Main(string[] args)
        {
            Person Praise;
            
          
        }
    }
}
