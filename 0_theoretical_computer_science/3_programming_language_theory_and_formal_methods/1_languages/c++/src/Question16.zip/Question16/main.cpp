#include <iostream>
#include "VectorCollection.h"
#include <iomanip>

using namespace std;

int main()
{
    	cout<< "Creating two Vector Collection objects, namely veggieVectorCollection and fruitVectorCollection" << endl;
        string veggies[]{"Carrot","Lettuce","Tomato","Cucumber","Brocolli"};
        string fruits[]{"Carrot","Orange","Banana","Tomato","Avocado"};

        VectorCollection veggieVectorCollection(veggies);
		VectorCollection fruitVectorCollection(fruits);

		cout << "Displaying veggieVectorCollection \n" << endl;
		veggieVectorCollection.displayVectorCollection();
		cout << "\n";

		cout << "Displaying fruitVectorCollection \n" << endl;
        fruitVectorCollection.displayVectorCollection();
        cout << "\n";


        vector <string> vectorNuts;
        vectorNuts.push_back("Walnuts");
        vectorNuts.push_back("Peanuts");
        vectorNuts.push_back("CashCew");

        cout << "Adding a nut vector to fruitVectorCollection \n";
        fruitVectorCollection.addVector(vectorNuts);
        cout << "Displaying new fruitVectorCollection \n" << endl;
        fruitVectorCollection.displayVectorCollection();
        cout << "\n";


        cout << "removing initial vector nut vector from fruitVectorCollection \n";
        fruitVectorCollection.removeVector(vectorNuts);
        cout << "Displaying new fruitVectorCollection " << endl;
        fruitVectorCollection.displayVectorCollection();
        cout << "\n";


        cout <<"Dispalying number of string in the fruitVectorCollection \n";
        cout << fruitVectorCollection.calNumOfString() << endl;

        cout << "Displaying veggieVectorCollection \n";
        veggieVectorCollection.displayVectorCollection();
        cout << "\n";

        cout << "Creating a fruitVegVector to use for testing the intersection function \n";
        vector <string> fruitVegVector;
        fruitVegVector.push_back("Carrot");
        fruitVegVector.push_back("Tomato");

        cout << "Displaying the content of fruitVegVector \n";
        for(int i = 0,vlength = fruitVegVector.size(); i < vlength; i++)
            cout <<fruitVegVector[i] <<" ";

        cout << endl;
        cout << "adding fruitVegVector to both veggieVectorCollection and fruitVectorCollection \n";
        veggieVectorCollection.addVector(fruitVegVector);
        fruitVectorCollection.addVector(fruitVegVector);

        cout << "Getting the intersection of veggieVectorCollection and fruitVectorCollection \n";
        vector <string> intersection;
        intersection = veggieVectorCollection * fruitVectorCollection;
        cout << "Displaying the instersction \n";

        if(intersection.empty())
            cout << "No intersection found \n";

        for(int i = 0,vecLength = intersection.size(); i <  vecLength;i++)
            cout << intersection[i]<< " ";
    return 0;
}
