#include "VectorCollection.h"
#include <iostream>

#define ARRAYSIZE 5

VectorCollection::VectorCollection(string stringArray[]) //NEED TO KNOW SIZE. ASSIGNMENT STATES ONLY ONE ARGUMENT
{
        //Initial Vectors in the list
        vector<string> vector1;

        for(int j = 0; j < ARRAYSIZE; j++)
        {
            vector1.push_back(stringArray[j]);
        }
        vectorList.push_back(vector1);
 }

VectorCollection::~VectorCollection()
{
    //dtor
}

void VectorCollection:: addVector(vector <string> inVector)
{
    vectorList.push_back(inVector);
}
void VectorCollection:: removeVector(vector <string> delVector)
{
    for(int i = 0,vectorLength = vectorList.size(); i < vectorLength;  i++)
    {
        if(vectorList[i] == delVector)
            vectorList.erase(vectorList.begin() + i);
    }
}
void VectorCollection:: clearVectorCollection()
{
    vectorList.clear();
}
int VectorCollection:: calNumOfString()
{
    int totalStringSum = 0;
    for(int i = 0,vectorLength = vectorList.size(); i < vectorLength;  i++)
    {
        totalStringSum += vectorList[i].size();
    }
    return totalStringSum;
}
void VectorCollection:: displayVectorCollection()
{

    for(int i = 0,vectorLength = vectorList.size(); i < vectorLength;  i++)
    {
        cout << "Displaying vector "<< i + 1 << " in the collection \n";
        for(int j = 0,vectorLength = vectorList[i].size(); j < vectorLength;  j++)
        {
            std::cout <<vectorList[i][j] << " ";//CHECK ME AGAIN!!
        }

    }

}

vector<string> VectorCollection:: operator * (VectorCollection inVectorCollection)
{
    vector<string> intersection;

    for(int i = 0,vectorLength = vectorList.size(); i < vectorLength;  i++)
    {
        for(int j = 0,vectorLength = inVectorCollection.vectorList.size() ; j < vectorLength;  j++)
        {
            if(vectorList[i] == inVectorCollection.vectorList[j])
            {
                intersection = inVectorCollection.vectorList[j];
                return intersection;
            }

        }
    }

    return intersection; //returns the vector empty
}
