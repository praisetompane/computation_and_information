#ifndef VECTORCOLLECTION_H
#define VECTORCOLLECTION_H

#include <vector>
#include <string>

using namespace std;

class VectorCollection
{
    public:
        VectorCollection(string stringArray[]);
        virtual ~VectorCollection();
        void addVector(vector <string> inVector);
        void removeVector(vector <string> delVector);
        void clearVectorCollection();
        int calNumOfString();
        void displayVectorCollection();

        //Operators
        vector<string> operator * (VectorCollection inVectorCollection);//Returns intersecetion

    protected:
    private:
        vector < vector<string> > vectorList;// remember to separate > > to not be confused with >>
};

#endif // VECTORCOLLECTION_H
