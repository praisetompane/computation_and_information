//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Generic.rc
//
#define IDD_ABOUT                       108
#define ID_MAIN                         109
#define ID_CAPTION                      110
#define ID_RS                           4001
#define IDM_EXIT                        4002
#define IDM_HELP                        4003
#define IDM_ABOUT                       4004
#define IDC_RS                          4005
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        110
#define _APS_NEXT_COMMAND_VALUE         4006
#define _APS_NEXT_CONTROL_VALUE         1002
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
