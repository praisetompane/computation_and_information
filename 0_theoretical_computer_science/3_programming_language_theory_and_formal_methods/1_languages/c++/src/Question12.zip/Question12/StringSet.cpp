#include "StringSet.h"
#include <string>


StringSet::~StringSet()
{
    //dtor
}

//Class Implementation

	//Constructor
StringSet::StringSet(string stringArray[],int arraySize)
{
		for(int i = 0;i < arraySize;i++ )
			stringList.push_back(stringArray[i]);

}

StringSet::StringSet()
{

}
	//Member functions
void StringSet::addString(string inString)
{
		stringList.push_back(inString);
}

void StringSet::removeString(string delString)
{
    for(int i = 0,vectorLength = stringList.size(); i < vectorLength;  i++)
    {
        if(stringList[i] == delString)
            stringList[i] = "";

    }
}
void StringSet::clearStrings()
{
		stringList.clear();
}
int StringSet::numOfStrings()
{
		return stringList.size();
}
void StringSet::displayStrings()
{
		for(int i = 0,vectorLength = stringList.size(); i < vectorLength;  i++)
			cout <<stringList[i] << " ";
			cout << endl;
}

StringSet StringSet ::operator + (StringSet inStringList)
{
		StringSet unionStrinSet;

		for(int i = 0, inStringListLength = inStringList.stringList.size();i < inStringListLength; i++)
		{
			for(int j = 0,stringListLength = stringList.size() ;j < stringListLength;j++)
			{
				if(inStringList.stringList[i] == stringList[j])
				{
				    unionStrinSet.addString(inStringList.stringList[i]);

				}

			}
		}

		return unionStrinSet;
}
	//Returns union
StringSet StringSet:: operator *(StringSet inStringList)
{
    StringSet intersection;
    for(int i = 0, inStringListLength = inStringList.stringList.size();i < inStringListLength; i++)
		{
			for(int j = 0,stringListLength = stringList.size() ;j < stringListLength;j++)
			{
				if(inStringList.stringList[i] == stringList[j])
				{
				    intersection.addString(inStringList.stringList[i]);
                    return intersection;
				}

			}
		}
}
