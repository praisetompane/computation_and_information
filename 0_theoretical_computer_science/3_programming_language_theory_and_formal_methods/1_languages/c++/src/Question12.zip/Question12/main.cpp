#include <iostream>

#include "StringSet.h"


using namespace std;

int main()
{

    	int ARRAY_SIZE = 5;
			string names[]{"Praise","Apple","Cat","Banana","Orange"};
			StringSet a(names,ARRAY_SIZE);

			cout << "Displaying string set\n";
			a.displayStrings();

			cout <<"Adding a string. The string is 'Henry'\n";
			a.addString("Henry");

			cout << "Displaying string set again\n";
			a.displayStrings();

			cout <<"Removing a string\n";
			a.removeString("Henry");

			cout << "Displaying string set the 3rd time\n";
			a.displayStrings();

			cout << "Displaying number of strings\n";
			cout<< a.numOfStrings() <<endl;

			cout << "Clearing string set\n";
			a.clearStrings();
			cout << "Displaying number of strings\n";
			cout<< a.numOfStrings() <<endl;;

			cout<< "Creating Two StringSet objects and arrays to fill them, namely VeggieList and FruitList \n";
			string veggies[]{"Carrot","Lettuce","Tomato","Cucumber","Brocolli"};
			string fruits[]{"Carrot","Orange","Banana","Tomato","Avocado"};
            StringSet veggieList(veggies,ARRAY_SIZE);
            StringSet fruitList(fruits,ARRAY_SIZE);

            cout << "Displaying FruitList \n";
            fruitList.displayStrings();
            cout<<"Displaying VeggieList \n";
            veggieList.displayStrings();

            StringSet vegFruiUnion = veggieList + fruitList;
            cout << "Displaying the union set of VeggieList and FruitList \n";
            vegFruiUnion.displayStrings();

            cout << "Displaying the intersection set of VeggieList and FruitList \n";
            StringSet vegFruitIntersction = veggieList * fruitList;
            vegFruitIntersction.displayStrings();

    return 0;
}
