#ifndef STRINGSET_H
#define STRINGSET_H

#include <vector>
#include <string>
#include <iostream>

using namespace std;

class StringSet
{
    public:
        StringSet(string stringArray[],int arraySize);
        StringSet();
        virtual ~StringSet();

         //Member functions
		void addString(string inString);

		void removeString(string delString);

		void clearStrings();

		int numOfStrings();

		void displayStrings();

		//Operators

		StringSet operator *(StringSet inStringList);//Returns instersection of two string sets
		StringSet operator +(StringSet inStringList);//Return the union of two string sets
    protected:
    private:
        vector <string> stringList;
};

#endif // STRINGSET_H
