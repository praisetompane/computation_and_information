#ifndef STUDENT_H
#define STUDENT_H

#include <string>
#include "InternalExamMarks.h"
#include "ExternalExamMarks.h"

using namespace std;

class Student : public InternalExamMarks, public ExternalExamMarks
{
    public:
        Student();
        virtual ~Student();

        void setStream(string inStream);
        string getStream();

        void setRollNumber(int inRollNumber);
        int getRollNumber();


    protected:
    private:
        string stream;
        int rollNumber;
};

#endif // STUDENT_H
