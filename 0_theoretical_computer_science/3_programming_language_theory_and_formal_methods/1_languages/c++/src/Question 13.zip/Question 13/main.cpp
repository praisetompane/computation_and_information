#include <iostream>

#include "Student.h"

using namespace std;

int main()
{
    cout << "Creating a student object" << endl;
    Student student1;
    cout << "Setting student roll number to 11 and stream to Science" << endl;

    student1.setRollNumber(11);
    student1.setStream("Science");

    cout << "Setting external marks" << endl;

    student1.setexternalModule1Mark(95);
    student1.setexternalmodule2Mark(100);

    cout << "Setting internal marks" << endl;

    student1.setinternalModule1Mark(78);
    student1.setinternalmodule2Mark(100);

    cout <<"Displaying external marks" << endl;
    cout <<"Internal mark 1: " << student1.getexternalModule1Mark() << endl;
    cout <<"Internal mark 2: " << student1.getexternalmodule2Mark() <<endl;

    cout <<"Displaying internal marks" << endl;
    cout <<"Internal mark 1: " << student1.getinternalModule1Mark() << endl;
    cout <<"Internal mark 2: " << student1.getinternalmodule2Mark() <<endl;

    return 0;
}
