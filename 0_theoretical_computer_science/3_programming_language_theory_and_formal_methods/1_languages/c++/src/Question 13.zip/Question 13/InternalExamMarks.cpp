#include "InternalExamMarks.h"

InternalExamMarks::InternalExamMarks()
{
    //ctor
}

InternalExamMarks::~InternalExamMarks()
{
    //dtor
}
void InternalExamMarks::setinternalModule1Mark(int mark)
{
	internalModule1Mark = mark;
}
int InternalExamMarks::getinternalModule1Mark()
{
	return internalModule1Mark;
}

void InternalExamMarks::setinternalmodule2Mark(int mark)
{
	internalModule2Mark = mark;
}
int InternalExamMarks::getinternalmodule2Mark()
{
	return internalModule2Mark;
}
