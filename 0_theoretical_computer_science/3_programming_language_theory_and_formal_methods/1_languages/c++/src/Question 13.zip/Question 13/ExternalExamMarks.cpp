#include "ExternalExamMarks.h"

ExternalExamMarks::ExternalExamMarks()
{
    //ctor
}

ExternalExamMarks::~ExternalExamMarks()
{
    //dtor
}

void ExternalExamMarks ::setexternalModule1Mark(int mark)
{
   externalModule1Mark = mark;
}
int ExternalExamMarks ::getexternalModule1Mark()
{
   return externalModule1Mark;
}

void ExternalExamMarks ::setexternalmodule2Mark(int mark)
{
   externalModule2Mark = mark;
}
int ExternalExamMarks ::getexternalmodule2Mark()
{
   return externalModule2Mark;
}
