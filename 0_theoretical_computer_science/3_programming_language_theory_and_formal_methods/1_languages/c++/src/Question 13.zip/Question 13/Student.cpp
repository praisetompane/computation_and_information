#include "Student.h"

Student::Student()
{
    //ctor
}

Student::~Student()
{
    //dtor
}
void Student :: setStream(string inStream)
{
    stream = inStream;
}
string Student :: getStream()
{
    return stream;
}

void Student :: setRollNumber(int inRollNumber)
{
    rollNumber = inRollNumber;
}
int Student :: getRollNumber()
{
    return rollNumber;
}
