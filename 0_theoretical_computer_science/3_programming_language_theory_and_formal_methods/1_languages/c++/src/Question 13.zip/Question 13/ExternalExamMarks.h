#ifndef EXTERNALEXAMMARKS_H
#define EXTERNALEXAMMARKS_H


class ExternalExamMarks
{
    public:
        ExternalExamMarks();
        virtual ~ExternalExamMarks();

    void setexternalModule1Mark(int mark);
	int getexternalModule1Mark();

	void setexternalmodule2Mark(int mark);
	int getexternalmodule2Mark();

    protected:
    private:
	    int externalModule1Mark, externalModule2Mark;
};

#endif // EXTERNALEXAMMARKS_H
