#ifndef INTERNALEXAMMARKS_H
#define INTERNALEXAMMARKS_H


class InternalExamMarks
{
    public:
        InternalExamMarks();
        virtual ~InternalExamMarks();

    void setinternalModule1Mark(int mark);
	int getinternalModule1Mark();

	void setinternalmodule2Mark(int mark);
	int getinternalmodule2Mark();

    protected:
    private:
	    int internalModule1Mark,internalModule2Mark;
};

#endif // INTERNALEXAMMARKS_H
